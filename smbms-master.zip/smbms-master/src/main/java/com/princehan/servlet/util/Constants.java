package com.princehan.servlet.util;

/**
 * @Description
 * @Author:PrinceHan
 * @CreateTime:2022/3/6 10:32
 */
public class Constants {
        public final static String USER_SESSION = "userSession";
}
