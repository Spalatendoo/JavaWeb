package com.princehan.dao.role;

import com.princehan.pojo.Role;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * @Description
 * @Author:PrinceHan
 * @CreateTime:2022/3/9 22:17
 */
public interface RoleDao {
        //获取角色列表
        List<Role> getRoleList(Connection con) throws SQLException;
}
